let fnamn = "Leon";
let enamn = "Hoffman-Krohn";
let minålder = 18;
console.log("Mitt namn är " + fnamn + " " + enamn +" Jag är " + minålder + " år")

// del 2
let namn = "Leon";
let födselÅr = 2005;
let år50 = födselÅr + 50;

console.log("År " + år50 + " blir " + namn + " 50 år gammal.");
