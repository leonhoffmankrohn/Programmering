let tal1 = 10;
let tal2 = 8;
let valdRäkneSätt = '/';

console.log("Tal1: " + tal1 + "\nTal2: " + tal2 + "\nValt räknesätt: " + valdRäkneSätt)

if (valdRäkneSätt == '+') console.log(tal1 + tal2); 
else if (valdRäkneSätt == '-') console.log(tal1 - tal2); 
else if (valdRäkneSätt == '*') console.log(tal1 * tal2); 
else if (valdRäkneSätt == '/') console.log(tal1 / tal2); 