let tal = 6;
let x = tal;
x++;
x *= 2;
x -= 6;
x /= 2;
x += 3;
x -= tal;
console.log(x);