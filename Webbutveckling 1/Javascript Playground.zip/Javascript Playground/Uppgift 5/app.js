let kostnad = 50;
let budget = 45;
console.log("Jag har råd: " + (budget >= kostnad))