let a = 1;
let b = 2;
let c = 3;
let d = 4;
let sum = a+b+c+d;
let average = sum / 4;
console.log("Sum: " + sum + " Avg:" + average);

// Triangelns area
let bas = 3;
let höjd = 2;
let area = bas * höjd / 2;
console.log("Traiangelns area: " + area);