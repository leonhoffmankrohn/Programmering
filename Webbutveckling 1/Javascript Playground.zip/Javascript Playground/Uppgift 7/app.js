let ålder = 20;
let kostnad15t65år = 20;
let kostnadÖvriga = 10;
console.log("Ålder? " + ålder + " år");

if (ålder < 65 && ålder > 15) console.log("Kostnaden blir: " + kostnad15t65år);
else console.log("Kostnaden blir: " + kostnadÖvriga);

